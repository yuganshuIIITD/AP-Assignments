package Assignment2;

public abstract class assesment {
    
}
