package Assignment2;

public class assignment extends assesment{
    private String problem_statement;
    private int marks;
    String status;
    public String getProblem_statement() {
        return problem_statement;
    }
    public void setProblem_statement(String problem_statement) {
        this.problem_statement = problem_statement;
    }
    public int getMarks() {
        return marks;
    }
    public void setMarks(int marks) {
        this.marks = marks;
    }
    
}
