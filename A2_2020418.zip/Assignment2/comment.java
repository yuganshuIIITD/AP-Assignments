package Assignment2;

import java.util.Date;

public class comment {
    private String name;
    private String comment;
    Date current_Date;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }
    public Date getCurrent_Date() {
        return current_Date;
    }
    public void setCurrent_Date(Date current_Date) {
        this.current_Date = current_Date;
    }
    
}
