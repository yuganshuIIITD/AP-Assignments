package Assignment2;

import java.util.Date;

public class lecturevid {
    private String topic;
    private String file_name;
    Date current_Date;
    String prof;
    public String getTopic() {
        return topic;
    }
    public void setTopic(String topic) {
        this.topic = topic;
    }
    public String getFile_name() {
        return file_name;
    }
    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }
    
}
