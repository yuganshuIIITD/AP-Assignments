package Assignment2;

public abstract class participants {
    
}
